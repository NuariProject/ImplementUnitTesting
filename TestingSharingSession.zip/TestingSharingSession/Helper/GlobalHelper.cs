﻿using TestingSharingSession.Interface;

namespace TestingSharingSession.Helper
{
    public class GlobalHelper
    {
        private ISharingSession _session;
        public GlobalHelper()
        {
            
        }

        public GlobalHelper(ISharingSession session)
        {
            _session = session;
        }

        public int PerkalianBilangBulat(int a, int b)
        {
            return a * b;
        }

        public string GetKey()
        {
            return "TestKey1";
        }

        public string ConvertBoolToText(bool param1)
        {
            try
            {
                if (_session.ValidasiModel())
                    // Tidak lanjut 
                    return string.Empty;

                return param1 ? "true" : "false";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

    }
}
