﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestingSharingSession.Interface;

namespace TestingSharingSession.Implement
{
    internal class SharingSession : ISharingSession
    {
        public bool ValidasiModel()
        {
            // sudah berhubungan dengan database
            return true;
        }
    }
}
