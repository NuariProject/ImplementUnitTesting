using Moq;
using TestingSharingSession.Helper;
using TestingSharingSession.Interface;

namespace UnitTestSharingSession
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            // Arrange
            GlobalHelper obj = new();

            // Act
            var result = obj.PerkalianBilangBulat(2,2);

            //Assert
            // 2*2 = 4
            Assert.Equal(4, result);
        }

        [Fact]
        public void Test2()
        {
            // Arrange
            GlobalHelper obj = new();
            string expected = "TestKey1";

            // Act
            var result = obj.GetKey();

            // Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void Test3() 
        {
            // Arrange
            Mock<ISharingSession> shsringMock = new();
            GlobalHelper obj = new(shsringMock.Object);
            string expected = "Test Error";

            shsringMock.Setup(ss => ss.ValidasiModel()).Throws(new Exception("Test Error"));

            // Act
            var result = obj.ConvertBoolToText(true);

            // Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void Test4()
        {
            // Arrange
            Mock<ISharingSession> shsringMock = new();
            GlobalHelper obj = new(shsringMock.Object);
            string expected = "true";

            shsringMock.Setup(ss => ss.ValidasiModel()).Returns(false);

            // Act
            var result = obj.ConvertBoolToText(true);

            // Assert
            Assert.Equal(expected, result);
        }
    }
}